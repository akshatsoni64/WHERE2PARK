# simple-login-qrcode-webcam-php
Just simple login using QR Code Scanner with Webcam in PHP modify from  ([https://github.com/LazarSoft/jsqrcode ](https://github.com/LazarSoft/jsqrcode )).

![qr-code](momo-qrcode.png)

# Demo
([Youtube Here](https://www.youtube.com/watch?v=805ZlfOLnU8))

([Visit Here](https://login-qrcode-webcam.herokuapp.com/))
